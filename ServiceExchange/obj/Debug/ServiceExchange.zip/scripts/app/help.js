/**
 * Help view model
 */
var app = app || {};

app.Help = (function () {
    'use strict';


        return {
            title: "Help"
        }
}());