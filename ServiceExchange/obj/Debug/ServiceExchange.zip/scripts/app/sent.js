/**
 * Sent view model
 */
var app = app || {};

app.Sent = (function () {
    'use strict';


        return {
            title: "Sent"
        }
}());