/**
 * About view model
 */
var app = app || {};

app.Inbox = (function () {
    'use strict';


        return {
            title: "Inbox"
        }
}());