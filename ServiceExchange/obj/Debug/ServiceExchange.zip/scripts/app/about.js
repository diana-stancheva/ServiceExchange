/**
 * About view model
 */
var app = app || {};

app.About = (function () {
    'use strict';


        return {
            title: "About"
        }
}());