/**
 * About view model
 */
var app = app || {};

app.MyExchanges = (function () {
    'use strict';


        return {
            title: "My Exchanges"
        }
}());