/**
 * About view model
 */
var app = app || {};

app.AppSettings = (function () {
    'use strict';


        return {
            title: "Settings"
        }
}());