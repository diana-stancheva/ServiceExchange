/**
 * About view model
 */
var app = app || {};

app.Exchanges = (function () {
    'use strict';

    var show = function (e) {

    }

    return {
        title: "All Exchanges",
        show: show
    }
}());