/**
 * Application Settings
 */
var appSettings = {

    everlive: {
        apiKey: 'iXjTywwyOUMukD8W', // Backend Services API key 
        scheme: 'http'
    }
}